create function add_para(v_num1 number,v_num2 number)
return number
is
  v_sum number(10);
begin
  v_sum := v_num1 + v_num2;
  return v_sum;
  
end;
/

