create function get_sal(dept_id number,total_count out number)
return number
is
   v_sumsal number(10) := 0;
   cursor salary_cursor is select salary from employees where department_id = dept_id;
begin
  total_count := 0;
  for c in salary_cursor loop
    v_sumsal := v_sumsal + c.salary;
    total_count := total_count+1;
  end loop;
  
  return v_sumsal;
end;
/

