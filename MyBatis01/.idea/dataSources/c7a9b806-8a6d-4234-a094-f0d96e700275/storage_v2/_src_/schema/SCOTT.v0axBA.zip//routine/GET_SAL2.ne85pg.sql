create procedure get_sal2(dept_id number,sumsal out number)
is
   cursor salary_cursor is select salary from employees where department_id = dept_id;
begin
  sumsal := 0;
  for c in salary_cursor loop
    sumsal := sumsal + c.salary;
  end loop;
  dbms_output.put_line(sumsal);
end;
/

