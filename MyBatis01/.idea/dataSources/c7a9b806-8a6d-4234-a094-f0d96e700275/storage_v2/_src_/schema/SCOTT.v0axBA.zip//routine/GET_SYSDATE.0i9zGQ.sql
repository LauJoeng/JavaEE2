create function get_sysdate
return date
is 
  v_date date;
begin
  v_date := sysdate;
  return v_date;
  
end;
/

