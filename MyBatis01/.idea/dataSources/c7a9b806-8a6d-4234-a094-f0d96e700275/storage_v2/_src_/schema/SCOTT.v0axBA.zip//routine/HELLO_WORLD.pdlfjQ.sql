create function hello_world
return varchar2
is 
begin 
  return 'hello world';
end;
/

