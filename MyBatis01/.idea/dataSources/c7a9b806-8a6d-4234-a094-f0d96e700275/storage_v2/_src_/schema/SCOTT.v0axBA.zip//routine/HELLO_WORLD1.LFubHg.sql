create function hello_world1(v_logo varchar2)
return varchar2
is 
begin 
  return 'hello world   '||v_logo;
end;
/

