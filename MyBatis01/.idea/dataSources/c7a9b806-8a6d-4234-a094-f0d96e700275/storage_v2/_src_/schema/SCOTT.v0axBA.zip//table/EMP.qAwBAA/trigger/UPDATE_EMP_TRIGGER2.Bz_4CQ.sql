create trigger UPDATE_EMP_TRIGGER2
  after update
  on EMP
  for each row
  begin
  dbms_output.put_line('old:salary:'||:old.salary ||','||'new salary:'||:new.salary);
end;
/

