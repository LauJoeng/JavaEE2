create trigger UPDATE_EMP_TRIGGER
  after update
  on EMPLOYEES
  for each row
  begin 
  dbms_output.put_line('hello world');
end;
/

