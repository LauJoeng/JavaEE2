create trigger UPDATE_EMP_TRIGGER1
  after update
  on EMPLOYEES
  begin 
  dbms_output.put_line('hello world');
end;
/

