create trigger DELETE_EMP_TRIGGER
  before delete
  on MY_EMP
  for each row
  begin
  insert into my_emp_bak
  values(:old.employee_id,:old.salary);
end;
/

