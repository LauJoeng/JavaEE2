create view EMPVIEW as
  select employee_id,last_name,salary
from employees 
where department_id=80

/

