create function f1()
  returns varchar(30)
  return date_format(now(),'%Y年%m月%d日%H点:%i分:%s秒');

