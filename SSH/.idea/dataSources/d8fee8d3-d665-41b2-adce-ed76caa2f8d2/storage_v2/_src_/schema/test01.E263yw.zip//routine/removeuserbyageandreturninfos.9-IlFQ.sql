create procedure removeUserByAgeAndReturnInfos(IN  p_age       smallint(5) unsigned,
                                               OUT deleteUsers smallint(5) unsigned,
                                               OUT userCounts  smallint(5) unsigned)
  begin
delete from users where age = p_age;
select row_count() into deleteUsers;
select count(id) from users into userCounts;
end;

