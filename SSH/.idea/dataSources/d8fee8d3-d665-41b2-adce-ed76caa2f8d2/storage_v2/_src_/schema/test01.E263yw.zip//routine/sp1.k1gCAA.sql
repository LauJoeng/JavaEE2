create procedure sp1()
  select version();

